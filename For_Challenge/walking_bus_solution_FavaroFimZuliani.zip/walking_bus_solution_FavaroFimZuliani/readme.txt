to compile the solution, use a C compiler, gcc on Linux or cl on the Developer Command Prompt of Windows should work.
to execute just input the name of the .dat file, the solver will generate the .sol file automatically
Ex.
> .\walking_bus2 test_instances\pedibus_10.dat


Solution made by:
Domenico Favaro 837995
Matheus Fim 876069
Caio Zuliani  877266